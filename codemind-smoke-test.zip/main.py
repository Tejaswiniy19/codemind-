
def calculate_total(price, quantity):
    return price * quantity


def apply_discount(total, discount):
    return total - (total * discount / 100)


if __name__ == "__main__":
    amount = calculate_total(100, 3)
    final_amount = apply_discount(amount, 10)

    print("Original amount:", amount)
    print("Final amount after discount:", final_amount)
